# Copyright (c) Twisted Matrix Laboratories.
# See LICENSE for details.

"""

Twisted News: an NNTP-based news service.

"""

from twisted.news._version import version
__version__ = version.short()
