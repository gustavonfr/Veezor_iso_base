from twisted.web import vhost

resource = vhost.VHostMonsterResource()

