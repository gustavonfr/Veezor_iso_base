# Copyright (c) Twisted Matrix Laboratories.
# See LICENSE for details.


"""Instance Messenger, Pan-protocol chat client."""

import warnings
warnings.warn("twisted.im will be undergoing a rewrite at some point in the future.")
