# This is an auto-generated file. Do not edit it.
from twisted.python import versions
version = versions.Version('twisted.mail', 11, 1, 0)
