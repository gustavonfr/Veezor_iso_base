/* ANSI-C code produced by gperf version 3.0.4 */
/* Command-line: gperf -t --output-file scripts/kconfig/zconf.hash.c_shipped -a -C -E -g -k '1,3,$' -p -t scripts/kconfig/zconf.gperf  */

#if !((' ' == 32) && ('!' == 33) && ('"' == 34) && ('#' == 35) \
      && ('%' == 37) && ('&' == 38) && ('\'' == 39) && ('(' == 40) \
      && (')' == 41) && ('*' == 42) && ('+' == 43) && (',' == 44) \
      && ('-' == 45) && ('.' == 46) && ('/' == 47) && ('0' == 48) \
      && ('1' == 49) && ('2' == 50) && ('3' == 51) && ('4' == 52) \
      && ('5' == 53) && ('6' == 54) && ('7' == 55) && ('8' == 56) \
      && ('9' == 57) && (':' == 58) && (';' == 59) && ('<' == 60) \
      && ('=' == 61) && ('>' == 62) && ('?' == 63) && ('A' == 65) \
      && ('B' == 66) && ('C' == 67) && ('D' == 68) && ('E' == 69) \
      && ('F' == 70) && ('G' == 71) && ('H' == 72) && ('I' == 73) \
      && ('J' == 74) && ('K' == 75) && ('L' == 76) && ('M' == 77) \
      && ('N' == 78) && ('O' == 79) && ('P' == 80) && ('Q' == 81) \
      && ('R' == 82) && ('S' == 83) && ('T' == 84) && ('U' == 85) \
      && ('V' == 86) && ('W' == 87) && ('X' == 88) && ('Y' == 89) \
      && ('Z' == 90) && ('[' == 91) && ('\\' == 92) && (']' == 93) \
      && ('^' == 94) && ('_' == 95) && ('a' == 97) && ('b' == 98) \
      && ('c' == 99) && ('d' == 100) && ('e' == 101) && ('f' == 102) \
      && ('g' == 103) && ('h' == 104) && ('i' == 105) && ('j' == 106) \
      && ('k' == 107) && ('l' == 108) && ('m' == 109) && ('n' == 110) \
      && ('o' == 111) && ('p' == 112) && ('q' == 113) && ('r' == 114) \
      && ('s' == 115) && ('t' == 116) && ('u' == 117) && ('v' == 118) \
      && ('w' == 119) && ('x' == 120) && ('y' == 121) && ('z' == 122) \
      && ('{' == 123) && ('|' == 124) && ('}' == 125) && ('~' == 126))
/* The character set is not based on ISO-646.  */
#error "gperf generated tables don't work with this execution character set. Please report a bug to <bug-gnu-gperf@gnu.org>."
#endif

#line 10 "scripts/kconfig/zconf.gperf"
struct kconf_id;

static const struct kconf_id *kconf_id_lookup(register const char *str, register unsigned int len);
/* maximum key range = 71, duplicates = 0 */

#ifdef __GNUC__
__inline
#else
#ifdef __cplusplus
inline
#endif
#endif
static unsigned int
kconf_id_hash (register const char *str, register unsigned int len)
{
  static const unsigned char asso_values[] =
    {
      73, 73, 73, 73, 73, 73, 73, 73, 73, 73,
      73, 73, 73, 73, 73, 73, 73, 73, 73, 73,
      73, 73, 73, 73, 73, 73, 73, 73, 73, 73,
      73, 73, 73, 73, 73, 73, 73, 73, 73, 73,
      73, 73, 73, 73, 73, 73, 73, 73, 73, 73,
      73, 73, 73, 73, 73, 73, 73, 73, 73, 73,
      73, 73, 73, 73, 73, 73, 73, 73, 73, 73,
      73, 73, 73, 73, 73, 73, 73, 73, 73, 73,
      73, 73, 73, 73, 73, 73, 73, 73, 73, 73,
      73, 73, 73, 73, 73, 73, 73, 73, 25, 25,
       0,  0,  0,  5,  0,  0, 73, 73,  5,  0,
      10,  5, 45, 73, 20, 20,  0, 15, 15, 73,
      20, 73, 73, 73, 73, 73, 73, 73, 73, 73,
      73, 73, 73, 73, 73, 73, 73, 73, 73, 73,
      73, 73, 73, 73, 73, 73, 73, 73, 73, 73,
      73, 73, 73, 73, 73, 73, 73, 73, 73, 73,
      73, 73, 73, 73, 73, 73, 73, 73, 73, 73,
      73, 73, 73, 73, 73, 73, 73, 73, 73, 73,
      73, 73, 73, 73, 73, 73, 73, 73, 73, 73,
      73, 73, 73, 73, 73, 73, 73, 73, 73, 73,
      73, 73, 73, 73, 73, 73, 73, 73, 73, 73,
      73, 73, 73, 73, 73, 73, 73, 73, 73, 73,
      73, 73, 73, 73, 73, 73, 73, 73, 73, 73,
      73, 73, 73, 73, 73, 73, 73, 73, 73, 73,
      73, 73, 73, 73, 73, 73, 73, 73, 73, 73,
      73, 73, 73, 73, 73, 73
    };
  register int hval = len;

  switch (hval)
    {
      default:
        hval += asso_values[(unsigned char)str[2]];
      /*FALLTHROUGH*/
      case 2:
      case 1:
        hval += asso_values[(unsigned char)str[0]];
        break;
    }
  return hval + asso_values[(unsigned char)str[len - 1]];
}

struct kconf_id_strings_t
  {
    char kconf_id_strings_str2[sizeof("if")];
    char kconf_id_strings_str3[sizeof("int")];
    char kconf_id_strings_str5[sizeof("endif")];
    char kconf_id_strings_str7[sizeof("default")];
    char kconf_id_strings_str8[sizeof("tristate")];
    char kconf_id_strings_str9[sizeof("endchoice")];
    char kconf_id_strings_str12[sizeof("def_tristate")];
    char kconf_id_strings_str13[sizeof("def_bool")];
    char kconf_id_strings_str14[sizeof("defconfig_list")];
    char kconf_id_strings_str17[sizeof("on")];
    char kconf_id_strings_str18[sizeof("optional")];
    char kconf_id_strings_str21[sizeof("option")];
    char kconf_id_strings_str22[sizeof("endmenu")];
    char kconf_id_strings_str23[sizeof("mainmenu")];
    char kconf_id_strings_str25[sizeof("menuconfig")];
    char kconf_id_strings_str27[sizeof("modules")];
    char kconf_id_strings_str29[sizeof("menu")];
    char kconf_id_strings_str31[sizeof("select")];
    char kconf_id_strings_str32[sizeof("comment")];
    char kconf_id_strings_str33[sizeof("env")];
    char kconf_id_strings_str35[sizeof("range")];
    char kconf_id_strings_str36[sizeof("choice")];
    char kconf_id_strings_str39[sizeof("bool")];
    char kconf_id_strings_str41[sizeof("source")];
    char kconf_id_strings_str42[sizeof("visible")];
    char kconf_id_strings_str43[sizeof("hex")];
    char kconf_id_strings_str46[sizeof("config")];
    char kconf_id_strings_str47[sizeof("boolean")];
    char kconf_id_strings_str51[sizeof("string")];
    char kconf_id_strings_str54[sizeof("help")];
    char kconf_id_strings_str56[sizeof("prompt")];
    char kconf_id_strings_str72[sizeof("depends")];
  };
static const struct kconf_id_strings_t kconf_id_strings_contents =
  {
    "if",
    "int",
    "endif",
    "default",
    "tristate",
    "endchoice",
    "def_tristate",
    "def_bool",
    "defconfig_list",
    "on",
    "optional",
    "option",
    "endmenu",
    "mainmenu",
    "menuconfig",
    "modules",
    "menu",
    "select",
    "comment",
    "env",
    "range",
    "choice",
    "bool",
    "source",
    "visible",
    "hex",
    "config",
    "boolean",
    "string",
    "help",
    "prompt",
    "depends"
  };
#define kconf_id_strings ((const char *) &kconf_id_strings_contents)
#ifdef __GNUC__
__inline
#if defined __GNUC_STDC_INLINE__ || defined __GNUC_GNU_INLINE__
__attribute__ ((__gnu_inline__))
#endif
#endif
const struct kconf_id *
kconf_id_lookup (register const char *str, register unsigned int len)
{
  enum
    {
      TOTAL_KEYWORDS = 32,
      MIN_WORD_LENGTH = 2,
      MAX_WORD_LENGTH = 14,
      MIN_HASH_VALUE = 2,
      MAX_HASH_VALUE = 72
    };

  static const struct kconf_id wordlist[] =
    {
      {-1}, {-1},
#line 25 "scripts/kconfig/zconf.gperf"
      {(int)(long)&((struct kconf_id_strings_t *)0)->kconf_id_strings_str2,		T_IF,		TF_COMMAND|TF_PARAM},
#line 36 "scripts/kconfig/zconf.gperf"
      {(int)(long)&((struct kconf_id_strings_t *)0)->kconf_id_strings_str3,		T_TYPE,		TF_COMMAND, S_INT},
      {-1},
#line 26 "scripts/kconfig/zconf.gperf"
      {(int)(long)&((struct kconf_id_strings_t *)0)->kconf_id_strings_str5,		T_ENDIF,	TF_COMMAND},
      {-1},
#line 29 "scripts/kconfig/zconf.gperf"
      {(int)(long)&((struct kconf_id_strings_t *)0)->kconf_id_strings_str7,	T_DEFAULT,	TF_COMMAND, S_UNKNOWN},
#line 31 "scripts/kconfig/zconf.gperf"
      {(int)(long)&((struct kconf_id_strings_t *)0)->kconf_id_strings_str8,	T_TYPE,		TF_COMMAND, S_TRISTATE},
#line 20 "scripts/kconfig/zconf.gperf"
      {(int)(long)&((struct kconf_id_strings_t *)0)->kconf_id_strings_str9,	T_ENDCHOICE,	TF_COMMAND},
      {-1}, {-1},
#line 32 "scripts/kconfig/zconf.gperf"
      {(int)(long)&((struct kconf_id_strings_t *)0)->kconf_id_strings_str12,	T_DEFAULT,	TF_COMMAND, S_TRISTATE},
#line 35 "scripts/kconfig/zconf.gperf"
      {(int)(long)&((struct kconf_id_strings_t *)0)->kconf_id_strings_str13,	T_DEFAULT,	TF_COMMAND, S_BOOLEAN},
#line 45 "scripts/kconfig/zconf.gperf"
      {(int)(long)&((struct kconf_id_strings_t *)0)->kconf_id_strings_str14,	T_OPT_DEFCONFIG_LIST,TF_OPTION},
      {-1}, {-1},
#line 43 "scripts/kconfig/zconf.gperf"
      {(int)(long)&((struct kconf_id_strings_t *)0)->kconf_id_strings_str17,		T_ON,		TF_PARAM},
#line 28 "scripts/kconfig/zconf.gperf"
      {(int)(long)&((struct kconf_id_strings_t *)0)->kconf_id_strings_str18,	T_OPTIONAL,	TF_COMMAND},
      {-1}, {-1},
#line 42 "scripts/kconfig/zconf.gperf"
      {(int)(long)&((struct kconf_id_strings_t *)0)->kconf_id_strings_str21,		T_OPTION,	TF_COMMAND},
#line 17 "scripts/kconfig/zconf.gperf"
      {(int)(long)&((struct kconf_id_strings_t *)0)->kconf_id_strings_str22,	T_ENDMENU,	TF_COMMAND},
#line 15 "scripts/kconfig/zconf.gperf"
      {(int)(long)&((struct kconf_id_strings_t *)0)->kconf_id_strings_str23,	T_MAINMENU,	TF_COMMAND},
      {-1},
#line 23 "scripts/kconfig/zconf.gperf"
      {(int)(long)&((struct kconf_id_strings_t *)0)->kconf_id_strings_str25,	T_MENUCONFIG,	TF_COMMAND},
      {-1},
#line 44 "scripts/kconfig/zconf.gperf"
      {(int)(long)&((struct kconf_id_strings_t *)0)->kconf_id_strings_str27,	T_OPT_MODULES,	TF_OPTION},
      {-1},
#line 16 "scripts/kconfig/zconf.gperf"
      {(int)(long)&((struct kconf_id_strings_t *)0)->kconf_id_strings_str29,		T_MENU,		TF_COMMAND},
      {-1},
#line 39 "scripts/kconfig/zconf.gperf"
      {(int)(long)&((struct kconf_id_strings_t *)0)->kconf_id_strings_str31,		T_SELECT,	TF_COMMAND},
#line 21 "scripts/kconfig/zconf.gperf"
      {(int)(long)&((struct kconf_id_strings_t *)0)->kconf_id_strings_str32,	T_COMMENT,	TF_COMMAND},
#line 46 "scripts/kconfig/zconf.gperf"
      {(int)(long)&((struct kconf_id_strings_t *)0)->kconf_id_strings_str33,		T_OPT_ENV,	TF_OPTION},
      {-1},
#line 40 "scripts/kconfig/zconf.gperf"
      {(int)(long)&((struct kconf_id_strings_t *)0)->kconf_id_strings_str35,		T_RANGE,	TF_COMMAND},
#line 19 "scripts/kconfig/zconf.gperf"
      {(int)(long)&((struct kconf_id_strings_t *)0)->kconf_id_strings_str36,		T_CHOICE,	TF_COMMAND},
      {-1}, {-1},
#line 33 "scripts/kconfig/zconf.gperf"
      {(int)(long)&((struct kconf_id_strings_t *)0)->kconf_id_strings_str39,		T_TYPE,		TF_COMMAND, S_BOOLEAN},
      {-1},
#line 18 "scripts/kconfig/zconf.gperf"
      {(int)(long)&((struct kconf_id_strings_t *)0)->kconf_id_strings_str41,		T_SOURCE,	TF_COMMAND},
#line 41 "scripts/kconfig/zconf.gperf"
      {(int)(long)&((struct kconf_id_strings_t *)0)->kconf_id_strings_str42,	T_VISIBLE,	TF_COMMAND},
#line 37 "scripts/kconfig/zconf.gperf"
      {(int)(long)&((struct kconf_id_strings_t *)0)->kconf_id_strings_str43,		T_TYPE,		TF_COMMAND, S_HEX},
      {-1}, {-1},
#line 22 "scripts/kconfig/zconf.gperf"
      {(int)(long)&((struct kconf_id_strings_t *)0)->kconf_id_strings_str46,		T_CONFIG,	TF_COMMAND},
#line 34 "scripts/kconfig/zconf.gperf"
      {(int)(long)&((struct kconf_id_strings_t *)0)->kconf_id_strings_str47,	T_TYPE,		TF_COMMAND, S_BOOLEAN},
      {-1}, {-1}, {-1},
#line 38 "scripts/kconfig/zconf.gperf"
      {(int)(long)&((struct kconf_id_strings_t *)0)->kconf_id_strings_str51,		T_TYPE,		TF_COMMAND, S_STRING},
      {-1}, {-1},
#line 24 "scripts/kconfig/zconf.gperf"
      {(int)(long)&((struct kconf_id_strings_t *)0)->kconf_id_strings_str54,		T_HELP,		TF_COMMAND},
      {-1},
#line 30 "scripts/kconfig/zconf.gperf"
      {(int)(long)&((struct kconf_id_strings_t *)0)->kconf_id_strings_str56,		T_PROMPT,	TF_COMMAND},
      {-1}, {-1}, {-1}, {-1}, {-1}, {-1}, {-1}, {-1}, {-1},
      {-1}, {-1}, {-1}, {-1}, {-1}, {-1},
#line 27 "scripts/kconfig/zconf.gperf"
      {(int)(long)&((struct kconf_id_strings_t *)0)->kconf_id_strings_str72,	T_DEPENDS,	TF_COMMAND}
    };

  if (len <= MAX_WORD_LENGTH && len >= MIN_WORD_LENGTH)
    {
      register int key = kconf_id_hash (str, len);

      if (key <= MAX_HASH_VALUE && key >= 0)
        {
          register int o = wordlist[key].name;
          if (o >= 0)
            {
              register const char *s = o + kconf_id_strings;

              if (*str == *s && !strncmp (str + 1, s + 1, len - 1) && s[len] == '\0')
                return &wordlist[key];
            }
        }
    }
  return 0;
}
#line 47 "scripts/kconfig/zconf.gperf"

