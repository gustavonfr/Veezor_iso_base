from landscape.patch import SQLiteUpgradeManager

upgrade_manager = SQLiteUpgradeManager()
