import pysvn

print 'pysvn.__doc__'
print pysvn.__doc__
print 'dir(pysvn)'
print dir(pysvn)
print 'pysvn.Client.__doc__'
print pysvn.Client.__doc__
print 'pysvn.Revision.__doc__'
print pysvn.Revision.__doc__
